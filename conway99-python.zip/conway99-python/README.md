# Conway 99-graph — Python verification code

All Python written to check the arithmetic behind the "Triangle-Orbit Congruences
for a Putative Conway 99-Graph" papers. **No papers here — code only.**

These scripts check *arithmetic*. They do NOT prove the theorems, do NOT verify
the imported fixed-point classification, and do NOT verify the main identity
`sum_{P<Q} f_PQ = 80 - t` (that is a proof about a hypothetical graph, not a
computation).

## Requirements

- Python 3.12 (any 3.8+ should work)
- `numpy`  — for everything in `verify/`
- `z3-solver` — only for `exploratory/z3*.py`   (`pip install z3-solver`)
- `ortools`   — only for `exploratory/cpsat*.py` (`pip install ortools`)

## verify/  — the checks actually relied on

| file | what it does |
|---|---|
| `verify_arithmetic.py` | **Canonical.** The script printed in Appendix A of the paper. Checks: spectrum multiplicities (54,44); congruence→candidate-set arithmetic ({6,27}, {2}, {7,21,35,49}); triangle count (693 edges, 231 triangles); the quotient identity `(M^2)_ij = (k-mu)delta + (lambda-mu)M_ij + mu|O_j|` on Paley(9)=srg(9,4,1,2) for all 72 automorphisms. Needs only numpy. |
| `audit-checks.py` | Same checks as `verify_arithmetic.py`, earlier framing (delivered during the audit). |
| `checks.py` | First version of the same checks (v0.4.1 audit). |
| `paley.py` | Builds Paley(9), enumerates its 72 automorphisms, and tests a quotient identity. **NOTE:** this first version used the wrong sign (`2|P|` instead of `2|Q|`), so it reports `identity_holds=False` for mixed orbit sizes. It is kept for provenance; `paley2.py` is the corrected one. |
| `paley2.py` | Corrected quotient-identity test: `(M^2)_ij = 2*delta_ij - M_ij + 2|O_j|` for srg(9,4,1,2). Holds for all 72 automorphisms. |

### Expected output of `verify_arithmetic.py`

```
TEST 1 (general): spectrum multiplicities for (99,14,1,2)
  f3 = 54   f-4 = 44
TEST 2 (general): congruence -> candidate sets
  T<=33, T=6 mod 21 : [6, 27]
  t<=20, t=2 mod 21 : [2]
  e<=49, 7|e, odd   : [7, 21, 35, 49]
TEST 3 (general): triangle count
  edges = 693  triangles = 231
TEST 4 (known example): quotient identity on Paley(9)
  automorphisms: 72   identity holds for all: True
NOTE: no test here verifies the main result sum f_PQ = 80 - t,
which is a proof about a hypothetical graph, not a computation.
```

## exploratory/ — solver attempts (did NOT settle anything)

These are the Z3 / CP-SAT encodings of the quotient-matrix system for the
order-3, three-fixed-vertex case. They were exploratory: the systems are hard
and the solvers either timed out ("unknown") or were superseded. They are
included because they are part of what was used, not because they verified a
result.

- `z3check.py`, `z3check2.py` — generic Z3 feasibility check, tested on Paley(9).
  `z3check.py` had a symmetry bug (forced symmetry across unequal orbit sizes);
  `z3check2.py` is the corrected version and reproduces the true quotient matrix.
- `z3q.py`, `z3q2.py`, `z3q3.py`, `z3q4.py` — Z3 models of the 99-vertex quotient
  system (35 orbits, then a reduced 32-orbit version). `z3q.py` had the same
  symmetry bug; the others are progressively corrected/hinted. All returned
  "unknown" within the time budget.
- `cpsat.py`, `cpsat2.py` — OR-Tools CP-SAT versions with native multiplication;
  also returned "unknown"/infeasible-or-timeout within budget.

None of the exploratory solvers produced a verified result; the paper's claims
rest on the proofs, not on these.

## What was actually verified

Only the arithmetic in `verify/`, plus a separate check that the authors'
GitHub repository (`YesterdaysLemon/conway-99-research`, commit `85e705c`) does
NOT contain the files its earlier drafts claimed. Neither of those verifies the
mathematics.
